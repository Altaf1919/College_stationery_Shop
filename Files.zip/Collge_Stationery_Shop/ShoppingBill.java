import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


     class Product{
        private String Category;
        private String Item;
        private int Quantity;
        private double Price;
        private double DiscountRate;
        private double DiscountApplied;
        private double TotalPrice;
        private double PriceAfterDiscount;

        Product(String Item,String Category,int Quantity,double Price,double DiscountRate,double DiscountApplied, double TotalPrice,double PriceAfterDiscount){
            this.Category=Category;
            this.Item=Item;
            this.Quantity=Quantity;
            this.Price=Price;
            this.DiscountRate=DiscountRate;
            this.DiscountApplied=DiscountApplied;
            this.TotalPrice=TotalPrice;
            this.PriceAfterDiscount=PriceAfterDiscount;
        }

        public String getCategory(){return Category;}
        public String getItem(){return Item;}
        public  int getQuantity(){return Quantity;}
        public double getPrice(){return Price;}
         public double getDiscountRate(){return DiscountRate;}
         public double getDiscountApplied(){return DiscountApplied;}
        public double getTotalPrice(){return TotalPrice;}

         public double getPriceAfterDiscount() {return PriceAfterDiscount;}

         public static void DisplayFormat() {
            System.out.format("------------------------------------------------------------------------------------------------------------------");
            System.out.print("\nCategory\t\tItem\t\tQuantitiy\t\tPrice\t\tDiscountRate\t\tDiscountApplied\t\tPriceAfterDiscount");
            System.out.format("\n------------------------------------------------------------------------------------------------------------------\n");
        }
        public void display() {
            System.out.format("%-9s     %-9s        %5d     %9.2f       %14.2f      %14.2f      %14.2f\n",Item,Category,Quantity,Price,DiscountRate,TotalPrice,PriceAfterDiscount);
        }

    }
    public class ShoppingBill {
        public static void main(String[] args) {
            String category = null;
            String item = null;
            int quantity = 0;
            double price = 0.0;
            double discountrate = 0.0;
            double discountapplied = 0.0;
            double Totalprice = 0.0;
            double priceafterdiscount = 0.0;
            double overAllPrice = 0.0;
            double SalesTax = 0.0;
            double GrossTotal = 0.0;
            char choice = '\0';
            System.out.println("\t\t\t------------------------COLLEGE STATIONARY SHOP-------------------");
            Scanner scan = new Scanner(System.in);
            List<Product> product = new ArrayList<Product>();
            do {
                //System.out.println("Enter the Item detail:");
                System.out.println("Enter the Category:");
                category = scan.nextLine();
                if (category.equals("Clothing") || category.equals("clothing") || category.equals("CLOTHING")) {
                    System.out.println("Enter the Item Name");
                    item = scan.nextLine();
                    if (item.equals("Shirt") || item.equals("shirt") || item.equals("SHIRT")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 2) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;
                    } else if (item.equals("Jacket") || item.equals("jacket") || item.equals("JACKET")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 2) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;
                    } else if (item.equals("Cap") || item.equals("cap") || item.equals("CAP")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 2) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;
                    }
                } else if (category.equals("Stationery") || category.equals("stationery") || category.equals("STATIONERY")) {
                    System.out.println("Enter the Item Name");
                    item = scan.nextLine();
                    if (item.equals("Notebook") || item.equals("notebook") || item.equals("NOTEBOOK")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 3) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;
                    } else if (item.equals("Pens") || item.equals("pens") || item.equals("PENS")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 3) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;
                    } else if (item.equals("Markers") || item.equals("markers") || item.equals("MARKERS")) {
                        System.out.println("Enter the Quantity:");
                        quantity = scan.nextInt();
                        if (quantity <= 3) {
                            System.out.println("Enter the Price of 1 item");
                            price = scan.nextDouble();
                            System.out.println("Discount Rate Applied");
                            discountrate = scan.nextDouble();
                            Totalprice = price * quantity;
                            System.out.println("ITEM_ADDED");
                        } else {
                            System.out.println("ERROR_QUANTITY_EXCEEDED");
                        }
                        if (Totalprice > 1000) {
                            discountapplied = Totalprice * discountrate / 100;
                        }
                        priceafterdiscount = Totalprice - discountapplied;


                        overAllPrice = overAllPrice + priceafterdiscount;
                        product.add(new Product(category, item, quantity, price, discountrate, Totalprice, discountapplied, priceafterdiscount));
                        System.out.println("Want to add more items?(y or n): ");
                        choice = scan.next().charAt(0);
                        scan.nextLine();
                    }
                }
            }while (choice == 'y' || choice == 'Y') ;
                    Product.DisplayFormat();
                    for (Product p : product) {
                        p.display();
                    }
                    System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTotal Price" + "  " + overAllPrice);
                    SalesTax = overAllPrice * 10 / 100;
                    System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tSales Tax(%)" + "  " + SalesTax);
                    GrossTotal = overAllPrice + SalesTax;
                    System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tGross Total" + "  " + GrossTotal);
                }




        }
    
